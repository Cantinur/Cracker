void brute_force(char* password, int x, int index, int start, int end);
void* brute_force_runner(void* arg);
void activate_brute_force(int num_thread);