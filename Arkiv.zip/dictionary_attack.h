void find_files();
void* look_in_fil_runner(void* arg);
void open_file(int num_thread);